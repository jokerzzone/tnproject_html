//var basemap="http://58.216.140.181:8399/arcgis/rest/services/CzsjtlyMap_compact/MapServer";
var basemap="http://58.216.140.181:8080/gxserver/MapService/czmapserver_sl_ags";
//var videomap="http://58.216.140.181:8399/arcgis/rest/services/CZSjtlyYX/MapServer";
var videomap="http://58.216.140.181:8080/gxserver/MapService/czmapserver_yx_ags";
//var upload="http://localhost:8090/toponym/servlet/dm_upLoad";
//var saveadress="http://192.168.1.220:8080/toponym/servlet/dm_declare";