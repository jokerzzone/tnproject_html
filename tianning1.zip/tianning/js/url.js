//var commonUrl = "http://58.216.140.181:8181/xbproject";
var commonUrl = "http://192.168.1.114:8080";
var mapUrl = "http://58.216.140.181:8181";
